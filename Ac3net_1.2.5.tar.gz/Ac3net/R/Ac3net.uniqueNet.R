#Ac3net: 
#This R package allows inferring directional conservative causal core network from large scale data.
#The inferred network consists of only direct physical interactions.
## Copyright (C) January 2011 Gokmen Altay <altaylabs@gmail.com>
## This program is a free software for only academic useage but not for commercial useage; you can redistribute it and/or
## modify it under the terms of the GNU GENERAL PUBLIC LICENSE
## either version 3 of the License, or any later version.
##
## This program is distributed WITHOUT ANY WARRANTY; 
## You can get a copy of the GNU GENERAL PUBLIC LICENSE
## from
## http://www.gnu.org/licenses/gpl.html
## See the licence information for the dependent package from
## igraph package itself.

#takes an 
Ac3net.uniqueNet <- function(netlist, directed=TRUE){
  #1 and 2. columns are gene names and , the rest is not important
    colnamesofnet <- colnames(netlist)
    netlist <- data.table(netlist)
    netlist[[1]] <- as.character(netlist[[1]])
    netlist[[2]] <- as.character(netlist[[2]])
    #
    netlist <- netlist[!( netlist[[1]]==netlist[[2]])] #removes dual links if any
    #
    if(directed == FALSE) netlist <- netlist[!duplicated(data.table(pmin(netlist[[1]],netlist[[2]]),
                                                                    pmax(netlist[[1]],netlist[[2]])))]
    
    if(directed != FALSE) netlist <-   netlist[!duplicated(data.table( netlist[[1]],netlist[[2]] ) )]
    
    colnames(netlist) <- colnamesofnet
    return(netlist)
  }
  