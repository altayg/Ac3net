#Ac3net: 
#This R package allows inferring directional conservative causal core network from large scale data.
#The inferred network consists of only direct physical interactions.
## Copyright (C) January 2011 Gokmen Altay <altayscience@gmail.com>
## This program is a free software for only academic useage but not for commercial useage; you can redistribute it and/or
## modify it under the terms of the GNU GENERAL PUBLIC LICENSE
## either version 3 of the License, or any later version.
##
## This program is distributed WITHOUT ANY WARRANTY; 
## You can get a copy of the GNU GENERAL PUBLIC LICENSE
## from
## http://www.gnu.org/licenses/gpl.html
## See the licence information for the dependent package from
## igraph package itself.

#takes an adjacency matrix and returns the absolute maximum correlated partner of each variable on the rows.
Ac3net.maxmim <- function(mim_, net_=TRUE, cutoff_=0)
{
  numprobs <- nrow(mim_)
  maxM <- c()
  mim_ <- Ac3net.filtersames(mim=mim_) ##first eliminates the same named pairs if exist.
  for(i in 1: numprobs){
    # if there are too many maximum partner, it may not be ideal!
    j<-c()
    #if all zero raw take just one
    if(min(mim_[i,])==0 & max(mim_[i,])==0){j<-1}else{
       j <- which( abs(mim_[i,])== max(abs(mim_[i,])) ) # compare magnitudes but not signs     
       } 
    if(length(j)>10){
      msg_ = paste("POTENTIAL ERROR, BE CAUTIOUS FOR THE RESULTS: There are more than 10 ,(",j,") maximum partner at row ", i, " name: ",rownames(mim_)[i])
      warning(msg_)
    }
    #
    tmp <- cbind(colnames(mim_)[j], rownames(mim_)[i], mim_[i,j], i, j) #source is in the second column
    maxM <- rbind(maxM,tmp)
  }
  colnames(maxM) <- c("Source","Target","CORR","RowIndx","ColIndx")
  if(net_==TRUE){
    maxM <- as.data.table(maxM)
    maxM <- maxM[abs(as.numeric(maxM$CORR))>cutoff_]
    maxM<- maxM[order(-abs(as.numeric(maxM$CORR)))]
    maxM$CORR <- as.numeric(maxM$CORR)
  }
  return(maxM)
}